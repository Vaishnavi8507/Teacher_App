package com.example.teacher_attendance

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
